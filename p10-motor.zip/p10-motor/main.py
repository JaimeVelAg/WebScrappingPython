# Práctica 10: Motor de Búsqueda
# Objetivo: Construir un motor de búsqueda de información en Internet
# ---------------------------------------------------------------------------
# Libreria para MongoDB
# pip install pymongo
# ----------------------------------------------------------------------------

# ------------------------------------ Librerias ------------------------------------
import pymongo
import json

from pymongo import MongoClient
from webScraping import hola
#------------------------------------------------------------------------------------

#Inicia el motor
def motorBusqueda(coleccion):
    #Optener el primer elemento que no esta revisado
    jsonQuery = coleccion.find_one({'revisada':False})
    print(jsonQuery)
    print(jsonQuery['direccion'])
    hola()
    
#Funcion principal
def main():
    # Conectar con el servidor de mongo DB
    cliente = MongoClient()
    db = cliente['BAD-Motor']  # Base de datos
    coleccion = db['Motor-Busqueda']  # Coleccion (Tabla)

    #Contar el numero de registros en la BD y si es 0 insertear el primer dato
    if coleccion.count_documents({}) == 0:
        # Insertar
        registroInicial = {
            "direccion": "http://sagitario.itmorelia.edu.mx/~rogelio/hola.htm",
            "titulo": "",
            "keywords": "",
            "descripcion": "",
            "palabra1": "",
            "palabra2": "",
            "palabra3": "",
            "ranking": 0,
            "revisada": False
        }
        coleccion.insert_one(registroInicial)
    
    # Iniciamos el motor
    motorBusqueda(coleccion)
    
if __name__ == "__main__":
    main()
